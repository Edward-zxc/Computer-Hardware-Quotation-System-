package com.jdbc.utils;

public class Const {
    public static final Integer USERON = 1;
    public static final Integer USEROFF = 0;
}
